# AgroDosar - generare APK Android

Acest proiect este pregatit pentru compilare ca APK Android.

## Varianta rapida cu Android Studio
1. Instaleaza Flutter SDK si Android Studio.
2. Dezarhiveaza proiectul.
3. In terminal, in folderul proiectului, ruleaza:

```bash
flutter pub get
flutter build apk --release
```

APK-ul se va gasi la:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Varianta GitHub Actions
1. Creeaza un repository pe GitHub.
2. Incarca tot continutul proiectului.
3. In tabul Actions ruleaza workflow-ul „Build Android APK”.
4. Descarca artefactul `agrodosar-release-apk`.

## Instalare pe telefon
1. Copiaza APK-ul pe telefon.
2. Deschide fisierul.
3. Permite instalarea din surse necunoscute, daca Android cere asta.
4. Instaleaza AgroDosar.
