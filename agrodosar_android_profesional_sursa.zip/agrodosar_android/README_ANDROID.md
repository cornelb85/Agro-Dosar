# AgroDosar Android

Aplicație Flutter pentru Android: parcele, culturi, lucrări, documente, termene și GPS.

## Cum o rulezi
1. Instalează Flutter și Android Studio.
2. Deschide folderul `agrodosar_android` în Android Studio.
3. Rulează:
   flutter pub get
   flutter run

## Cum generezi APK
flutter build apk --release

APK-ul va fi în:
build/app/outputs/flutter-apk/app-release.apk
