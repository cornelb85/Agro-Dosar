package com.agrodosar.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
