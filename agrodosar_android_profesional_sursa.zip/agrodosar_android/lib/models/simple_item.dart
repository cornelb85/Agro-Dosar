class SimpleItem {
  final int? id;
  final String title;
  final String subtitle;
  final String date;
  final int? parcelaId;
  final String type;

  const SimpleItem({this.id, required this.title, required this.subtitle, required this.date, this.parcelaId, required this.type});
  Map<String, dynamic> toMap() => {'id': id, 'title': title, 'subtitle': subtitle, 'date': date, 'parcelaId': parcelaId, 'type': type};
  factory SimpleItem.fromMap(Map<String, dynamic> m) => SimpleItem(id: m['id'], title: m['title'] ?? '', subtitle: m['subtitle'] ?? '', date: m['date'] ?? '', parcelaId: m['parcelaId'], type: m['type'] ?? '');
}
