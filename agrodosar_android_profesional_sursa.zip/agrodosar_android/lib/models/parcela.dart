class Parcela {
  final int? id;
  final String denumire;
  final String tarla;
  final String parcela;
  final double suprafataHa;
  final String folosinta;
  final String drept;
  final double? lat;
  final double? lng;
  final String observatii;

  const Parcela({this.id, required this.denumire, required this.tarla, required this.parcela, required this.suprafataHa, required this.folosinta, required this.drept, this.lat, this.lng, required this.observatii});

  Map<String, dynamic> toMap() => {'id': id, 'denumire': denumire, 'tarla': tarla, 'parcela': parcela, 'suprafataHa': suprafataHa, 'folosinta': folosinta, 'drept': drept, 'lat': lat, 'lng': lng, 'observatii': observatii};

  factory Parcela.fromMap(Map<String, dynamic> m) => Parcela(id: m['id'] as int?, denumire: m['denumire'] ?? '', tarla: m['tarla'] ?? '', parcela: m['parcela'] ?? '', suprafataHa: (m['suprafataHa'] as num?)?.toDouble() ?? 0, folosinta: m['folosinta'] ?? '', drept: m['drept'] ?? '', lat: (m['lat'] as num?)?.toDouble(), lng: (m['lng'] as num?)?.toDouble(), observatii: m['observatii'] ?? '');
}
