import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/parcela.dart';
import '../models/simple_item.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'agrodosar.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE parcele(id INTEGER PRIMARY KEY AUTOINCREMENT, denumire TEXT NOT NULL, tarla TEXT, parcela TEXT, suprafataHa REAL, folosinta TEXT, drept TEXT, lat REAL, lng REAL, observatii TEXT)''');
      await db.execute('''CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subtitle TEXT, date TEXT, parcelaId INTEGER, type TEXT NOT NULL)''');
    });
    return _db!;
  }

  Future<int> insertParcela(Parcela p) async => (await db).insert('parcele', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  Future<List<Parcela>> getParcele() async => (await (await db).query('parcele', orderBy: 'id DESC')).map((e) => Parcela.fromMap(e)).toList();
  Future<double> totalHa() async {
    final r = await (await db).rawQuery('SELECT SUM(suprafataHa) as total FROM parcele');
    return (r.first['total'] as num?)?.toDouble() ?? 0;
  }
  Future<int> countParcele() async {
    final r = await (await db).rawQuery('SELECT COUNT(*) as c FROM parcele');
    return (r.first['c'] as int?) ?? 0;
  }
  Future<int> insertItem(SimpleItem item) async => (await db).insert('items', item.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  Future<List<SimpleItem>> getItems(String type) async => (await (await db).query('items', where: 'type=?', whereArgs: [type], orderBy: 'id DESC')).map((e) => SimpleItem.fromMap(e)).toList();
  Future<int> countItems(String type) async {
    final r = await (await db).rawQuery('SELECT COUNT(*) as c FROM items WHERE type=?', [type]);
    return (r.first['c'] as int?) ?? 0;
  }
}
