import 'package:flutter/material.dart';
import '../db/app_database.dart';
import '../widgets/app_drawer.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int parcele = 0, culturi = 0, lucrari = 0, termene = 0;
  double ha = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    parcele = await AppDatabase.instance.countParcele();
    ha = await AppDatabase.instance.totalHa();
    culturi = await AppDatabase.instance.countItems('cultura');
    lucrari = await AppDatabase.instance.countItems('lucrare');
    termene = await AppDatabase.instance.countItems('termen');
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        drawer: const AppDrawer(),
        appBar: AppBar(title: const Text('AgroDosar')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.pushNamed(context, '/adauga-parcela').then((_) => _load()),
          icon: const Icon(Icons.add_location_alt),
          label: const Text('Parcelă'),
        ),
        body: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: LinearGradient(
                    colors: [
                      Theme.of(context).colorScheme.primaryContainer,
                      Theme.of(context).colorScheme.secondaryContainer,
                    ],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Gestiune agricultură, APIA și acte',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('Parcelele, culturile, lucrările, fotografiile GPS și termenele importante într-un singur dosar digital.'),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
                children: [
                  _statCard('Parcelele', '$parcele', Icons.map_outlined),
                  _statCard('Suprafață', '${ha.toStringAsFixed(2)} ha', Icons.square_foot),
                  _statCard('Culturi', '$culturi', Icons.grass),
                  _statCard('Lucrări', '$lucrari', Icons.agriculture),
                  _statCard('Termene', '$termene', Icons.event_available),
                  _statCard('Documente', 'PDF/Foto', Icons.folder_copy_outlined),
                ],
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/parcele'),
                icon: const Icon(Icons.map),
                label: const Text('Deschide fișele parcelelor'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/termene'),
                icon: const Icon(Icons.notifications_active_outlined),
                label: const Text('Calendar termene APIA / instanță'),
              ),
            ],
          ),
        ),
      );

  Widget _statCard(String title, String value, IconData icon) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, size: 30),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  Text(title),
                ],
              ),
            ],
          ),
        ),
      );
}
