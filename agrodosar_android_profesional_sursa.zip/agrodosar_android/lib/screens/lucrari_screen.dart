import 'culturi_screen.dart';
class LucrariScreen extends LucrariLikeScreen { const LucrariScreen({super.key}) : super('lucrare','Lucrări agricole','Adaugă lucrare','ex: Erbicidat parcela A107/1','utilaj, cost, substanță, observații'); }
