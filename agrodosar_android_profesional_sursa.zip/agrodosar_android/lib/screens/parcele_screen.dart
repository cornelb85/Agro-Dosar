import 'package:flutter/material.dart';
import '../db/app_database.dart';
import '../models/parcela.dart';
import '../widgets/app_drawer.dart';

class ParceleScreen extends StatefulWidget { const ParceleScreen({super.key}); @override State<ParceleScreen> createState()=>_ParceleScreenState(); }
class _ParceleScreenState extends State<ParceleScreen>{ List<Parcela> data=[]; @override void initState(){super.initState(); _load();} Future<void> _load() async {data=await AppDatabase.instance.getParcele(); if(mounted)setState((){});} @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Parcelele mele')), drawer:const AppDrawer(), floatingActionButton:FloatingActionButton(onPressed:()=>Navigator.pushNamed(context,'/adauga-parcela').then((_)=>_load()), child:const Icon(Icons.add)), body:data.isEmpty?const Center(child:Text('Nu există parcele. Adaugă prima parcelă.')):ListView.builder(itemCount:data.length,itemBuilder:(c,i){final p=data[i];return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(leading:const Icon(Icons.map),title:Text(p.denumire),subtitle:Text('T${p.tarla} / P${p.parcela} • ${p.suprafataHa} ha • ${p.folosinta}\n${p.drept}${p.lat!=null?' • GPS: ${p.lat!.toStringAsFixed(5)}, ${p.lng!.toStringAsFixed(5)}':''}'),isThreeLine:true));}));}
