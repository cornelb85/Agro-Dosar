import 'culturi_screen.dart';
class TermeneScreen extends LucrariLikeScreen { const TermeneScreen({super.key}) : super('termen','Termene','Adaugă termen','ex: APIA - depunere cerere','dată, instituție, dosar, observații'); }
