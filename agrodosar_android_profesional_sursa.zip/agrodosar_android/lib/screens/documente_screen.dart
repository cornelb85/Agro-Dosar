import 'culturi_screen.dart';
class DocumenteScreen extends LucrariLikeScreen { const DocumenteScreen({super.key}) : super('document','Documente','Adaugă document','ex: CF 101816','tip act, număr, instituție, observații'); }
