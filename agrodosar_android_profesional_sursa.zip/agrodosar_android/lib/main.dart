import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/parcele_screen.dart';
import 'screens/add_parcela_screen.dart';
import 'screens/culturi_screen.dart';
import 'screens/lucrari_screen.dart';
import 'screens/documente_screen.dart';
import 'screens/termene_screen.dart';

void main() => runApp(const AgroDosarApp());

class AgroDosarApp extends StatelessWidget {
  const AgroDosarApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF2E7D32);
    return MaterialApp(
      title: 'AgroDosar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        appBarTheme: const AppBarTheme(centerTitle: false, elevation: 0),
        cardTheme: CardThemeData(
          elevation: 1.2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          margin: EdgeInsets.zero,
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          filled: true,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      routes: {
        '/': (_) => const DashboardScreen(),
        '/parcele': (_) => const ParceleScreen(),
        '/adauga-parcela': (_) => const AddParcelaScreen(),
        '/culturi': (_) => const CulturiScreen(),
        '/lucrari': (_) => const LucrariScreen(),
        '/documente': (_) => const DocumenteScreen(),
        '/termene': (_) => const TermeneScreen(),
      },
    );
  }
}
