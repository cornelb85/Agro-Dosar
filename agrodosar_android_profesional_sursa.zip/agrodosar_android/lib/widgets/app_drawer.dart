import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('Dashboard', '/', Icons.dashboard),
      ('Parcelele mele', '/parcele', Icons.map),
      ('Culturi', '/culturi', Icons.grass),
      ('Lucrări', '/lucrari', Icons.agriculture),
      ('Documente', '/documente', Icons.folder),
      ('Termene', '/termene', Icons.event),
    ];
    return Drawer(child: ListView(children: [
      const DrawerHeader(child: Text('AgroDosar', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold))),
      ...items.map((e) => ListTile(leading: Icon(e.$3), title: Text(e.$1), onTap: () => Navigator.pushReplacementNamed(context, e.$2))),
    ]));
  }
}
